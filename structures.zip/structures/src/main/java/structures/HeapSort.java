package structures;

import java.util.PriorityQueue;

public class HeapSort {
			
	public static double[] sort(double[] array){
		PriorityQueue<Double> tab = new PriorityQueue<Double>();
		
	}
}
