package structures;

public class MyClass {
	public static int result() {
		return 36;
	}
}
