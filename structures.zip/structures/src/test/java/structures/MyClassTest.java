package structures;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MyClassTest {

	@Test
	public void test1() {
		assertEquals(36, MyClass.result());
	}
}
