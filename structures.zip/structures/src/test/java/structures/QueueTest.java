package structures;

import java.util.ArrayDeque;
import java.util.PriorityQueue;

public class QueueTest {
	 public static void main(String[] args) {
	        QueueTest.playWithQueue();
	        QueueTest.playWithStack();
	        QueueTest.playWithPriorityQueue();
	        QueueTest.playWithMaxPriorityQueue();
	    }
	 
	 private static void playWithQueue() {
		 System.out.println("File");
		 ArrayDeque<Double> file = new ArrayDeque<Double>();
		 
		 file.addLast(3.0);
		 file.addLast(1.0);
		 file.addLast(2.0);
		 file.addLast(4.0);
		 
		 while(!file.isEmpty()) {
			 System.out.println(file.element());
			 file.removeFirst();
		 }
		 
	 }
	 
	 private static void playWithStack() {
		 System.out.println("Pile");
		 ArrayDeque<Double> pile = new ArrayDeque<Double>();
		 
		 pile.addFirst(4.0);
		 pile.addFirst(2.0);
		 pile.addFirst(1.0);
		 pile.addFirst(3.0);
		 
		 while(!pile.isEmpty()) {
			 System.out.println(pile.element());
			 pile.removeFirst();
		 }
	 }
	 
	 private static void playWithPriorityQueue(){
		 PriorityQueue<Double> pileQ = new PriorityQueue<Double>();
		 
		 pileQ.add(3.0);
		 pileQ.add(1.0);
		 pileQ.add(2.0);
		 pileQ.add(4.0);
		 
		 while(!pileQ.isEmpty()) {
			 System.out.println(pileQ.element());
			 pileQ.remove();
		 }
	 }
	 
	 private static void playWithMaxPriorityQueue(){
		 PriorityQueue<Double> pileQ = new PriorityQueue<Double>(QueueTest::maxCompare);
		 
		 pileQ.add(3.0);
		 pileQ.add(1.0);
		 pileQ.add(2.0);
		 pileQ.add(4.0);
		 
		 while(!pileQ.isEmpty()) {
			 System.out.println(pileQ.element());
			 pileQ.remove();
		 }
	 }
	 
	 private static int maxCompare(double x, double y) {
			 return (Double.compare(y, x));
	 }
	 
}

